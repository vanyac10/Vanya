# main.py - The View Layer
from app.schedule import ScheduleManager

def front_desk_daily_roster(manager, day):
    """Displays a pretty table of all lessons on a given day."""
    print(f"\n--- Daily Roster for {day} ---")
    found = False
    for course in manager.courses:
        for lesson in course.lessons:
            if lesson['day'].lower() == day.lower():
                print(f"Course: {course.name} | Time: {lesson['start_time']} | Room: {lesson['room']}")
                found = True
                
    if not found:
        print(f"No lessons scheduled for {day}.")

def switch_course(manager, student_id, from_course_id, to_course_id):
    """Implement the logic to switch a student by calling methods on the manager."""
    manager.switch_student_course(student_id, from_course_id, to_course_id)

def main():
    """Main function to run the MSMS application."""
    manager = ScheduleManager() # Create ONE instance of the application brain.
    print(f"DEBUG: Loaded {len(manager.courses)} courses and {len(manager.students)} students.") # Add this line
    
    while True:
        print("\n===== MSMS v3 (Object-Oriented) =====")
        print("1. View Daily Roster for a Day")
        print("2. Check-in Student for a Course")
        print("3. Switch Student Course")
        print("q. Quit")
        choice = input("Enter choice: ")
        
        if choice == '1':
            day = input("Enter day (e.g., Monday): ")
            front_desk_daily_roster(manager, day)
        elif choice == '2': # Changed to elif
            try:
                student_id = int(input("Enter Student ID: "))
                course_id = int(input("Enter Course ID: "))
                manager.check_in(student_id, course_id)
            except ValueError:
                print("Error: Student ID and Course ID must be valid numbers.")
        elif choice == '3': # Added the missing option 3
            try:
                student_id = int(input("Enter Student ID: "))
                from_id = int(input("Enter Current Course ID to switch from: "))
                to_id = int(input("Enter New Course ID to switch to: "))
                switch_course(manager, student_id, from_id, to_id)
            except ValueError:
                print("Error: IDs must be valid numbers.")
        elif choice.lower() == 'q':
            print("Exiting application. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")
        
if __name__ == "__main__":
    main()