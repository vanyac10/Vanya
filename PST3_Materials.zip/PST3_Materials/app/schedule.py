import json
import datetime
from app.student import StudentUser
from app.teacher import TeacherUser, Course

class ScheduleManager:
    """The main controller for all business logic and data handling."""
    def __init__(self, data_path="data/msms.json"):
        self.data_path = data_path
        self.students = []
        self.teachers = []
        self.courses = []
        self.attendance_log = []
        self._load_data()

    def _load_data(self):
        """Loads data from the JSON file and populates the object lists."""
        try:
            with open(self.data_path, 'r') as f:
                data = json.load(f)
                # Load students
                for s_data in data.get("students", []):
                    student = StudentUser(s_data["id"], s_data["name"])
                    student.enrolled_course_ids = s_data.get("enrolled_course_ids", [])
                    self.students.append(student)
                    
                # Load teachers
                for t_data in data.get("teachers", []):
                    self.teachers.append(TeacherUser(t_data["id"], t_data["name"], t_data.get("speciality", "")))
                    
                # Load courses
                for c_data in data.get("courses", []):
                    course = Course(c_data["id"], c_data["name"], c_data["instrument"], c_data["teacher_id"])
                    course.enrolled_student_ids = c_data.get("enrolled_student_ids", [])
                    course.lessons = c_data.get("lessons", [])
                    self.courses.append(course)

                # Safely load the attendance log using .get()
                self.attendance_log = data.get("attendance", [])
        except FileNotFoundError:
            print("Data file not found. Starting with a clean state.")
    
    def _save_data(self):
        """Converts object lists back to dictionaries and saves to JSON."""
        data_to_save = {
            "students": [s.__dict__ for s in self.students],
            "teachers": [t.__dict__ for t in self.teachers],
            "courses": [c.__dict__ for c in self.courses],
            "attendance": self.attendance_log,
        }
        with open(self.data_path, 'w') as f:
            json.dump(data_to_save, f, indent=4)

    def find_student_by_id(self, student_id):
        """Helper to find a student by ID."""
        return next((s for s in self.students if s.id == int(student_id)), None)

    def find_course_by_id(self, course_id):
        """Helper to find a course by ID."""
        return next((c for c in self.courses if c.id == int(course_id)), None)

    def check_in(self, student_id, course_id):
        """Records a student's attendance for a course after validation."""
        student = self.find_student_by_id(student_id)
        course = self.find_course_by_id(course_id)
        
        if not student or not course:
            print("Error: Check-in failed. Invalid Student or Course ID.")
            return False
            
        timestamp = datetime.datetime.now().isoformat()
        check_in_record = {"student_id": int(student_id), "course_id": int(course_id), "timestamp": timestamp}
        
        self.attendance_log.append(check_in_record)
        self._save_data()
        print(f"Success: Student {student.name} checked into {course.name}.")
        return True

    def switch_student_course(self, student_id, from_course_id, to_course_id):
        """Switches a student from one course to another with validation and persistence."""
        student = self.find_student_by_id(student_id)
        from_course = self.find_course_by_id(from_course_id)
        to_course = self.find_course_by_id(to_course_id)

        if not student or not from_course or not to_course:
            print("Error: Course switch failed. Invalid Student, From-Course, or To-Course ID.")
            return False

        if from_course_id not in student.enrolled_course_ids:
            print(f"Error: Student is not currently enrolled in course ID {from_course_id}.")
            return False

        # Update student and course relationships
        student.enrolled_course_ids.remove(from_course_id)
        if student_id in from_course.enrolled_student_ids:
            from_course.enrolled_student_ids.remove(student_id)

        if to_course_id not in student.enrolled_course_ids:
            student.enrolled_course_ids.append(to_course_id)
        if student_id not in to_course.enrolled_student_ids:
            to_course.enrolled_student_ids.append(student_id)

        self._save_data()
        print(f"Success: Switched {student.name} from {from_course.name} to {to_course.name}.")
        return True