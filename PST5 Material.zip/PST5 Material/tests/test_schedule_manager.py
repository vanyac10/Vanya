# tests/test_schedule_manager.py
import os
import pytest
from app.schedule import ScheduleManager

# Use a separate test file so we don't overwrite real data
TEST_DATA_PATH = "data/test_msms.json"

@pytest.fixture
def manager():
    """Sets up a fresh ScheduleManager before each test and cleans up after."""
    # Arrange: Create a clean manager for testing
    mgr = ScheduleManager(data_path=TEST_DATA_PATH)
    mgr.students = []
    mgr.finance_log = []
    yield mgr
    # Cleanup: Remove the test file after the test finishes
    if os.path.exists(TEST_DATA_PATH):
        os.remove(TEST_DATA_PATH)

def test_register_new_student(manager):
    """Test that a new student is properly created and saved."""
    # Act
    student = manager.register_new_student("Test User", "Piano")
    
    # Assert
    assert student is not None
    assert student.name == "Test User"
    assert len(manager.students) == 1
    assert manager.students[0].id == student.id

def test_record_payment_success(manager):
    """Test that payments are recorded successfully for existing students."""
    # Arrange
    manager.register_new_student("Finance Test", "Guitar")
    student_id = manager.students[0].id
    
    # Act
    success = manager.record_payment(student_id, 150.00, "Cash")
    
    # Assert
    assert success is True
    assert len(manager.finance_log) == 1
    assert manager.finance_log[0]["amount"] == 150.00
    assert manager.finance_log[0]["method"] == "Cash"

def test_record_payment_invalid_student(manager):
    """Test that payments fail gracefully if the student does not exist."""
    # Act
    success = manager.record_payment(999, 100.00, "Credit Card")
    
    # Assert
    assert success is False
    assert len(manager.finance_log) == 0

def test_record_payment_and_history(manager):
    # ARRANGE: Register a student first so ID 1 exists in the system
    student = manager.register_new_student("Test Student", "Piano")
    student_id_to_test = student.id

    # ACT 1: Record a payment for that student
    manager.record_payment(student_id_to_test, 100.00, "Credit Card")

    # ACT 2: Get the payment history
    history = manager.get_payment_history(student_id_to_test)

    # ASSERT: Check the results
    assert len(history) == 1
    assert history[0]["amount"] == 100.00
    assert history[0]["method"] == "Credit Card"