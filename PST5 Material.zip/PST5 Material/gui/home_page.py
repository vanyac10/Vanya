# gui/home_page.py
import streamlit as st

def show_home_page(manager):
    """Renders the main Home dashboard landing page with working navigation buttons."""
    st.title("Music School Management System")
    st.write("Welcome to the MSMS central administration dashboard.")
    
    st.divider()

    # --- System Summary Metrics ---
    st.subheader("System Overview")
    col1, col2, col3 = st.columns(3)
    
    total_students = len(getattr(manager, 'students', []))
    total_teachers = len(getattr(manager, 'teachers', []))
    total_courses = len(getattr(manager, 'courses', []))

    with col1:
        st.metric(label="Registered Students", value=total_students)
    with col2:
        st.metric(label="Active Teachers", value=total_teachers)
    with col3:
        st.metric(label="Enrolled Courses", value=total_courses)

    st.divider()

    # --- Quick Navigation Buttons ---
    st.subheader("Quick Navigation")
    st.write("Click any module below to jump directly to that page:")

    col_a, col_b = st.columns(2)

    with col_a:
        if st.button("Student Management", use_container_width=True):
            st.session_state.current_page = "Student Management"
            st.rerun()
        st.caption("Search registered students and add new student profiles.")

        st.write("")

        if st.button("Daily Roster", use_container_width=True):
            st.session_state.current_page = "Daily Roster"
            st.rerun()
        st.caption("Mark student attendance and view daily scheduled sessions.")

    with col_b:
        if st.button("Teachers", use_container_width=True):
            st.session_state.current_page = "Teachers"
            st.rerun()
        st.caption("View teacher directories and register new teaching staff.")

        st.write("")

        if st.button("Finance", use_container_width=True):
            st.session_state.current_page = "Finance"
            st.rerun()
        st.caption("Record student tuition payments, view history, and export data reports.")