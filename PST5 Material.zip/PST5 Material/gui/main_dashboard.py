# gui/main_dashboard.py
import streamlit as st
from app.schedule import ScheduleManager
from gui.home_page import show_home_page
from gui.student_pages import show_student_management_page
from gui.roster_pages import show_roster_page
from gui.finance_pages import show_finance_page
from gui.teacher_pages import show_teacher_page

def launch():
    """Sets up the main Streamlit application window and navigation."""
    st.set_page_config(layout="wide", page_title="Music School Management System")

    # Instantiate manager once in session state
    if 'manager' not in st.session_state:
        st.session_state.manager = ScheduleManager()

    # Track active page in session state
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "Home"

    modules = ["Home", "Student Management", "Teachers", "Daily Roster", "Finance"]

    # Calculate index based on current active page
    current_idx = modules.index(st.session_state.current_page) if st.session_state.current_page in modules else 0

    st.sidebar.title("MSMS Navigation")

    # Callback when user manually clicks sidebar radio
    def sync_radio():
        st.session_state.current_page = st.session_state.radio_selection

    st.sidebar.radio(
        "Select a module:",
        options=modules,
        index=current_idx,
        key="radio_selection",
        on_change=sync_radio
    )

    # Page Routing based on current_page
    active_page = st.session_state.current_page
    if active_page == "Home":
        show_home_page(st.session_state.manager)
    elif active_page == "Student Management":
        show_student_management_page(st.session_state.manager)
    elif active_page == "Teachers":
        show_teacher_page(st.session_state.manager)
    elif active_page == "Daily Roster":
        show_roster_page(st.session_state.manager)
    elif active_page == "Finance":
        show_finance_page(st.session_state.manager)