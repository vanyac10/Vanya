# gui/teacher_pages.py
import streamlit as st
import pandas as pd
from app.teacher import TeacherUser

def show_teacher_page(manager):
    """Renders the Teacher Management page."""
    st.header("Teacher Management")

    # --- View Teachers Section ---
    st.subheader("Teacher Directory")
    if manager.teachers:
        teacher_data = []
        for t in manager.teachers:
            # Find courses taught by this teacher
            courses_taught = [c.name for c in manager.courses if getattr(c, 'teacher_id', None) == t.id]
            teacher_data.append({
                "Teacher ID": t.id,
                "Name": t.name,
                "Instrument/Specialty": getattr(t, 'instrument', 'N/A'),
                "Assigned Courses": ", ".join(courses_taught) if courses_taught else "None"
            })
        
        df = pd.DataFrame(teacher_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No teachers currently registered in the system.")

    st.divider()

    # --- Add Teacher Section ---
    st.subheader("Register New Teacher")
    with st.form("register_teacher_form"):
        name = st.text_input("Teacher Name")
        instrument = st.text_input("Primary Instrument / Specialty")
        submitted = st.form_submit_button("Add Teacher")

        if submitted:
            if name:
                new_id = len(manager.teachers) + 1
                new_teacher = TeacherUser(new_id, name)
                if hasattr(new_teacher, 'instrument'):
                    new_teacher.instrument = instrument
                
                manager.teachers.append(new_teacher)
                if hasattr(manager, '_save_data'):
                    manager._save_data()
                
                st.success(f"Successfully registered teacher {name} (ID: {new_id})!")
                st.balloons()
            else:
                st.warning("Please provide a name for the teacher.")