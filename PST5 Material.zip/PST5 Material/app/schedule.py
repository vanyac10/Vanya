import logging
import json
import datetime
import csv  # Required for exporting reports
from app.student import StudentUser
from app.teacher import TeacherUser, Course

class ScheduleManager:
    """The main controller for all business logic and data handling."""
    def __init__(self, data_path="data/msms.json"):
        self.data_path = data_path
        self.students = []
        self.teachers = []
        self.courses = []
        self.attendance_log = []
        self.finance_log = []  # NEW for PST5
        self._load_data()

    def find_student_by_id(self, student_id):
        """Helper method to find a student object by ID."""
        for student in self.students:
            if student.id == int(student_id):
                return student
        return None

    def find_student_by_id(self, student_id):
        """Finds and returns a student object matching the given ID."""
        for student in self.students:
            if student.id == int(student_id):
                return student
        return None

    def create_course(self, name, instrument, teacher_id):
        """Creates a new course, saves data, and returns the course object."""
        new_id = len(self.courses) + 1
        new_course = Course(new_id, name, instrument, teacher_id)
        self.courses.append(new_course)
        self._save_data()
        return new_course
    
    def record_payment(self, student_id, amount, method):
            """Adds a payment record to the finance log."""
            student = self.find_student_by_id(student_id)
            if not student:
                print(f"Error: Cannot record payment. Student ID {student_id} not found.")
                return False
                
            payment_record = {
                "student_id": int(student_id),
                "amount": float(amount),
                "method": method,
                "timestamp": datetime.datetime.now().isoformat()
            }
            
            self.finance_log.append(payment_record)
            self._save_data()
    
            # Add a log entry after a successful operation
            logging.info(f"Payment of {amount} recorded for student ID {student_id}.")
            
            print(f"Payment of {amount} for student {student_id} recorded.")
            return True
    
    def _load_data(self):
        try:
            with open(self.data_path, 'r') as f:
                data = json.load(f)
                # ... existing logic ...
                self.finance_log = data.get("finance", [])  # NEW for PST5
        except FileNotFoundError:
            print("Data file not found. Starting with a clean state.")
            
    def _save_data(self):
        """Converts object lists back to dictionaries and saves to JSON."""
        data_to_save = {
            "students": [s.__dict__ for s in self.students],
            "teachers": [t.__dict__ for t in self.teachers],
            "courses": [c.__dict__ for c in self.courses],
            "attendance": self.attendance_log,
            "finance": self.finance_log,  # NEW for PST5
        }
        with open(self.data_path, 'w') as f:
            json.dump(data_to_save, f, indent=4)

    def get_payment_history(self, student_id):
        """Returns a list of all payments for a given student."""
        return [p for p in self.finance_log if p['student_id'] == int(student_id)]

    def register_new_student(self, name, instrument):
        """Creates a new student, saves to data, and returns the object."""
        new_id = len(self.students) + 1  # Simple ID generation
        new_student = StudentUser(new_id, name)
        
        self.students.append(new_student)
        self._save_data()
        
        # Log the registration for PST5
        logging.info(f"New student registered: {name} (ID: {new_id})")
        
        return new_student
    
    def export_report(self, kind, out_path):
        """Exports a log to a CSV file."""
        print(f"Exporting {kind} report to {out_path}...")
        
        if kind == "finance":
            data_to_export = self.finance_log
            headers = ["student_id", "amount", "method", "timestamp"]
        elif kind == "attendance":
            data_to_export = getattr(self, 'attendance_log', [])
            headers = ["student_id", "course_id", "timestamp"]
        else:
            print("Error: Unknown report type.")
            return False

        if not data_to_export:
            print(f"No {kind} data available to export.")
            return False

        try:
            with open(out_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=headers)
                writer.writeheader()
                writer.writerows(data_to_export)
            return True
        except Exception as e:
            print(f"Failed to export data: {e}")
            return False