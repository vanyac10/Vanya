#The Persistent Application
import json
import datetime

DATA_FILE = "msms.json"
app_data = {}

# --- Core Persistence Engine ---
def load_data(path=DATA_FILE):
    """Loads all application data from a JSON file."""
    global app_data
    try:
        with open(path, 'r') as f:
            app_data = json.load(f)
            print("Data loaded successfully.")
    except FileNotFoundError:
        print("Data file not found. Initializing with default structure.")
        app_data = {
            "students": [],
            "teachers": [],
            "attendance": [],
            "next_student_id": 1,
            "next_teacher_id": 1
        }

def save_data(path=DATA_FILE):
    """Saves all application data to a JSON file."""
    with open(path, 'w') as f:
        json.dump(app_data, f, indent=4)
    print("Data saved successfully.")

# --- Full CRUD for Core Data ---
def add_teacher(name, speciality):
    """Adds a teacher dictionary to the data store."""
    teacher_id = app_data['next_teacher_id']
    new_teacher = {"id": teacher_id, "name": name, "speciality": speciality}
    app_data['teachers'].append(new_teacher)
    app_data['next_teacher_id'] += 1
    print(f"Core: Teacher '{name}' added.")

def update_teacher(teacher_id, **fields):
    """Finds a teacher by ID and updates their data with provided fields."""
    for teacher in app_data['teachers']:
        if teacher['id'] == teacher_id:
            teacher.update(fields)
            print(f"Teacher {teacher_id} updated.")
            return
    print(f"Error: Teacher with ID {teacher_id} not found.")

def remove_student(student_id):
    """Removes a student from the data store."""
    for student in app_data['students']:
        if student['id'] == student_id:
            student_to_remove = student
            break
            
    if student_to_remove is not None:
        app_data['students'].remove(student_to_remove)
        print(f"Student {student_id} removed.")
    else:
        print(f"Error: Student with ID {student_id} not found.")


# TODO: Implement remove_teacher() and update_student() using the patterns above.
def remove_teacher(teacher_id):
    """Removes a teacher from the data store."""
    teacher_to_remove = None
    for teacher in app_data['teachers']:
        if teacher['id'] == teacher_id:
            teacher_to_remove = teacher
            break

    if teacher_to_remove is not None:
        app_data['teachers'].remove(teacher_to_remove)
        print(f"Teacher {teacher_id} removed.")
    else:
        print(f"Error: Teacher with ID {teacher_id} not found.")

def update_student(student_id, **fields):
    """Finds a student by ID and updates their data with provided fields."""
    for student in app_data['students']:
        if student['id'] == student_id:
            student.update(fields)
            print(f"Student {student_id} updated.")
            return
    print(f"Error: Student with ID {student_id} not found.")

# --- New Receptionist Features ---
def check_in(student_id, course_id, timestamp=None):
    """Records a student's attendance for a course."""
    if timestamp is None:
        timestamp = datetime.datetime.now().isoformat()
    
    check_in_record = {
        "student_id": student_id,
        "course_id": course_id,
        "timestamp": timestamp
    }
    app_data['attendance'].append(check_in_record)
    print(f"Receptionist: Student {student_id} checked into {course_id}.")

def print_student_card(student_id):
    """Creates a text file badge for a student."""
    student_to_print = None
    for s in app_data['students']:
        if s['id'] == student_id:
            student_to_print = s
            break
    
    if student_to_print:
        filename = f"{student_id}_card.txt"
        with open(filename, 'w') as f:
            f.write("========================\n")
            f.write(f"  MUSIC SCHOOL ID BADGE\n")
            f.write("========================\n")
            f.write(f"ID: {student_to_print['id']}\n")
            f.write(f"Name: {student_to_print['name']}\n")
            f.write(f"Enrolled In: {', '.join(student_to_print.get('enrolled_in', []))}\n")
        print(f"Printed student card to {filename}.")
    else:
        print(f"Error: Could not print card, student {student_id} not found.")

# --- Main Application Loop ---
def main():
    """Main function to run the MSMS application."""
    load_data()

    while True:
        print("\n===== MSMS v2 (Persistent) =====")
        print("1. Check-in Student")
        print("2. Print Student Card")
        print("3. Update Teacher Info")
        print("4. Remove Student")
        print("q. Quit and Save")
        
        choice = input("Enter your choice: ")
        
        made_change = False
        if choice == '1':
            try:
                s_id = int(input("Enter student ID: "))
                c_id = input("Enter course ID: ")
                check_in(s_id, c_id)
                made_change = True
            except ValueError:
                print("Error: Student ID must be a valid integer. Please try again.")
        elif choice == '2':
            try:
                s_id = int(input("Enter student ID: "))
                print_student_card(s_id)
            except ValueError:
                print("Error: Student ID must be an integer.")
        elif choice == '3':
            try:
                t_id = int(input("Enter teacher ID to update: "))
                new_name = input("Enter new name (leave blank to skip): ")
                new_speciality = input("Enter new speciality (leave blank to skip): ")
                
                updates = {}
                if new_name:
                    updates['name'] = new_name
                if new_speciality:
                    updates['speciality'] = new_speciality
                    
                if updates:
                    update_teacher(t_id, **updates)
                    made_change = True
                else:
                    print("No fields to update.")
            except ValueError:
                print("Error: Teacher ID must be an integer.")
            made_change = True
        elif choice == '4':
            try:
                s_id = int(input("Enter student ID to remove: "))
                remove_student(s_id)
                made_change = True
            except ValueError:
                print("Error: Student ID must be an integer.")
            made_change = True
        elif choice.lower() == 'q':
            print("Saving final changes and exiting.")
            break
        else:
            print("Invalid choice.")
            
        if made_change:
            save_data()

    save_data()

# --- Program Start ---
if __name__ == "__main__":
    main()